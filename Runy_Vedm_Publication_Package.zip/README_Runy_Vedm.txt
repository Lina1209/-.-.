РУНЫ ВЕДЬМ / RUNY VEDM — PACKAGE
=================================

Files:
- Runy_Vedm_Bilingual.ttf      Installable TrueType font for desktop apps.
- Runy_Vedm_Bilingual.otf      OpenType version preserving original CFF outlines.
- Runy_Vedm_Bilingual.woff2    Modern web font.
- Runy_Vedm_Bilingual.woff     Web fallback.
- Runy_Vedm_Original.otf       Original character mapping preserved, metadata normalized.
- Runy_Vedm_Character_Map.pdf  Printable glyph/mapping overview.
- Runy_Vedm_Character_Map.png  Preview sheet.
- SOURCE_Runy_Vedm.otf         Uploaded source file.

IMPORTANT MAPPING NOTES
-----------------------
The uploaded font contains 32 glyph records and 31 Unicode assignments:
space, digit 0, Cyrillic uppercase Ё and А–Ъ, and Euro sign.
It does not contain separate drawn glyphs for the full 33-letter Russian alphabet
or for all 26 Latin letters as a distinct alphabet.

The bilingual build preserves original mappings, adds lowercase aliases for the
existing Cyrillic letters, and maps Latin A-Z/a-z to the closest available Cyrillic
rune glyphs by this explicit alias table:
A=А, B=Б, C=С, D=Д, E=Е, F=Ф, G=Г, H=Х, I=И, J=Ж, K=К, L=Л, M=М,
N=Н, O=О, P=Р, Q=К, R=Р, S=С, T=Т, U=У, V=В, W=Ш, X=Х, Y=Й, Z=З.
Some Latin letters intentionally share glyphs because the source has no separate
designs for them. Missing Russian letters Д... etc are not fabricated: only glyphs
actually present in the uploaded source are mapped. The font is not a transliteration
tool; it changes appearance only and does not convert text content.

PUBLICATION
-----------
Before public release, add your chosen license (for example OFL only if you intend
to release under its terms), copyright/author attribution, version history, and
a clear character map. Do not claim OFL licensing unless you have actually chosen it.
Google Docs does not allow arbitrary uploaded fonts to be added to its standard
font menu; use in a web page or desktop apps that support custom fonts.
